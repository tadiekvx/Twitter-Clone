namespace TwitterClone.Domain.Entities
{
    public enum NotificationType
    {
        Follow,
        Mention,
        Answer,
        RePost,
        Like
    }
}
