﻿using Microsoft.AspNetCore.Identity;

namespace TwitterClone.Infrastructure.Identity
{
    public class ApplicationUser : IdentityUser
    {
    }
}
